override['poise-service']['provider'] = 'dummy'
